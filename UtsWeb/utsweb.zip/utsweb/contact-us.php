<?php
  include_once "koneksi.php";
  if (isset($_POST["message"])) {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $message = $_POST["message"];

    $sql = "INSERT INTO contact (name, email, message) VALUES ('$name','$email','$message')";
    $runSQL = mysqli_query($conn, $sql);
    if ($runSQL) {
      header("location:contact-us.php?pesanterkirim");
    }
  }
?>
<!DOCTYPE html>
<html class="wide wow-animation" lang="en">
  <head>
    <!-- Site Title-->
    <title>Contact Us</title>
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <link rel="icon" href="images/logo.jpg" type="image/x-icon">
    <!-- Stylesheets-->
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Lato:300,400,700,400italic%7CJosefin+Sans:400,700,300italic">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
    <style>.ie-panel{display: none;background: #212121;padding: 10px 0;box-shadow: 3px 3px 5px 0 rgba(0,0,0,.3);clear: both;text-align:center;position: relative;z-index: 1;} html.ie-10 .ie-panel, html.lt-ie-10 .ie-panel {display: block;}</style>
  </head>
  <body>
    <!-- Page Loader-->
    <div id="page-loader">
      <div class="page-loader-body">
        <div class="cssload-spinner">
          <div class="cssload-cube cssload-cube0"></div>
          <div class="cssload-cube cssload-cube1"></div>
          <div class="cssload-cube cssload-cube2"></div>
          <div class="cssload-cube cssload-cube3"></div>
          <div class="cssload-cube cssload-cube4"></div>
          <div class="cssload-cube cssload-cube5"></div>
          <div class="cssload-cube cssload-cube6"> </div>
          <div class="cssload-cube cssload-cube7"></div>
          <div class="cssload-cube cssload-cube8"></div>
          <div class="cssload-cube cssload-cube9"></div>
          <div class="cssload-cube cssload-cube10"></div>
          <div class="cssload-cube cssload-cube11"></div>
          <div class="cssload-cube cssload-cube12"></div>
          <div class="cssload-cube cssload-cube13"></div>
          <div class="cssload-cube cssload-cube14"></div>
          <div class="cssload-cube cssload-cube15"></div>
        </div>
      </div>
    </div>
    <!-- Page-->
    <div class="page">
      <?php
          include_once "header.php";
      ?>

      <!-- Breadcrumbs-->
      <section class="breadcrumbs-custom bg-image" style="background-image: url(images/34.jpg);">
        <div class="shell">
          <h1 class="breadcrumbs-custom__title">Contact Us</h1>
          <ul class="breadcrumbs-custom__path">
            <li><a href="index.php">Home</a></li>
            <li class="active">Contact Us</li>
          </ul>
        </div>
      </section>

      <!-- Get in Touch-->
      <section class="section section-md bg-white text-center">
        <div class="shell">
          <div class="range range-md-center">
            <div class="cell-md-11 cell-lg-10">
              <h2 class="text-bold">Suggestions</h2>
              <p><span class="box-width-2">Silahkan Kritik dan Saran anda tentang saya.</span></p>
              <div class="layout-columns"> 
                <div class="layout-columns__main">
                  <div class="layout-columns__main-inner">
                    <!-- RD Mailform-->
                    <form class="rd-mailform" data-form-output="form-output-global" data-form-type="contact" method="post" action="contact-us.php">
                      <div class="form-wrap">
                        <input class="form-input" id="name" type="text" name="name" data-constraints="@Required">
                        <label class="form-label" for="name">Name</label>
                      </div>
                      <div class="form-wrap">
                        <input class="form-input" id="email" type="email" name="email" data-constraints="@Email @Required">
                        <label class="form-label" for="email">E-mail</label>
                      </div>
                      <div class="form-wrap">
                        <label class="form-label" for="message">Your Message</label>
                        <textarea class="form-input" id="message" name="message" data-constraints="@Required"></textarea>
                      </div>
                      <div class="form-wrap form-button offset-1">
                        <button class="button button-block button-primary-outline button-ujarak" type="submit">Send Message</button>
                      </div>
                    </form>
                  </div>
                </div>
                <div class="layout-columns__aside">
                  <div class="layout-columns__aside-item">
                    <p class="heading-5">Socials</p>
                    <div class="divider-modern"></div>
                    <ul class="list-inline-xs">
                    <li><a class="icon icon-sm fa fa-instagram icon-style-camera" href="https://www.instagram.com/"><span></span><span></span><span></span><span></span></a></li>
                      <li><a class="icon icon-sm fa fa-facebook icon-style-camera" href="https://www.facebook.com/"><span></span><span></span><span></span><span></span></a></li>
                      <li><a class="icon icon-sm fa fa-twitter icon-style-camera" href="https://twitter.com/"><span></span><span></span><span></span><span></span></a></li>
                      <li><a class="icon icon-sm fa fa-envelope icon-style-camera" href="https://gmail.com"><span></span><span></span><span></span><span></span></a></li>
                    </ul>
                  </div>
                  <div class="layout-columns__aside-item">
                    <p class="heading-5">Phone</p>
                    <div class="divider-modern"></div>
                    <div class="unit unit-horizontal unit-spacing-xxs">
                      <div class="unit__left"><span class="icon icon-md icon-primary material-icons-local_phone"></span></div>
                      <div class="unit__body"><a href="tel:#">081-2345-6789</a></div>
                    </div>
                  </div>
                  <div class="layout-columns__aside-item">
                    <p class="heading-5">Address</p>
                    <div class="divider-modern"></div>
                    <div class="unit unit-horizontal unit-spacing-xxs">
                      <div class="unit__left"><span class="icon icon-md icon-primary material-icons-location_on"></span></div>
                      <div class="unit__body"><a href="#">Amarapura Village Tangsel. 15313</a></div>
                    </div>
                  </div>
                  <div class="layout-columns__aside-item">
                    <p class="heading-5">Location</p>
                    <div class="divider-modern"></div>
                    <div class="unit unit-horizontal unit-spacing-xxs">
                      <div class="unit__left"><span class="icon icon-md icon-primary material-icons-location_on"></span></div>
                      <div class="unit__body"><span>JAKARTA, INDONESIA</span></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <?php
        include_once "footer.php";
      ?>
    </div>
    <!-- Javascript-->
    <script src="js/core.min.js"></script>
    <script src="js/script.js"></script>
  </body>
</html>