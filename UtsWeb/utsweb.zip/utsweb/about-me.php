<!DOCTYPE html>
<html class="wide wow-animation" lang="en">
  <head>
    <!-- Site Title-->
    <title>About Me</title>
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <link rel="icon" href="images/logo.jpg" type="image/x-icon">
    <!-- Stylesheets-->
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Lato:300,400,700,400italic%7CJosefin+Sans:400,700,300italic">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
    <style>.ie-panel{display: none;background: #212121;padding: 10px 0;box-shadow: 3px 3px 5px 0 rgba(0,0,0,.3);clear: both;text-align:center;position: relative;z-index: 1;} html.ie-10 .ie-panel, html.lt-ie-10 .ie-panel {display: block;}</style>
  </head>
  <body>
    <!-- Page Loader-->
    <div id="page-loader">
      <div class="page-loader-body">
        <div class="cssload-spinner">
          <div class="cssload-cube cssload-cube0"></div>
          <div class="cssload-cube cssload-cube1"></div>
          <div class="cssload-cube cssload-cube2"></div>
          <div class="cssload-cube cssload-cube3"></div>
          <div class="cssload-cube cssload-cube4"></div>
          <div class="cssload-cube cssload-cube5"></div>
          <div class="cssload-cube cssload-cube6"> </div>
          <div class="cssload-cube cssload-cube7"></div>
          <div class="cssload-cube cssload-cube8"></div>
          <div class="cssload-cube cssload-cube9"></div>
          <div class="cssload-cube cssload-cube10"></div>
          <div class="cssload-cube cssload-cube11"></div>
          <div class="cssload-cube cssload-cube12"></div>
          <div class="cssload-cube cssload-cube13"></div>
          <div class="cssload-cube cssload-cube14"></div>
          <div class="cssload-cube cssload-cube15"></div>
        </div>
      </div>
    </div>
    <!-- Page-->
    <div class="page">
      <?php
          include_once "header.php";
      ?>
      
      <!-- Breadcrumbs-->
      <section class="breadcrumbs-custom bg-image" style="background-image: url(images/25.jpg);">
        <div class="shell">
          <h1 class="breadcrumbs-custom__title">About Me</h1>
          <ul class="breadcrumbs-custom__path">
            <li><a href="index.php">Home</a></li>
            <li class="active">About Me</li>
          </ul>
        </div>
      </section>
      

      <!-- About Me-->
      
      <section class="section section-md bg-white">
        <div class="shell">
          <div class="range range-50 range-sm-center range-md-left">
            <div class="cell-sm-6 cell-md-5">
              <div class="thumb-bordered"><img src="images/23.jpg" alt="" width="437" height="435"/>
              </div>
            </div>
            <div class="cell-sm-6 cell-md-7">
              <div class="box-width-3 box-centered">
                <article class="quote-big">
                  <p class="q">My Achievement</p>
                </article>
                <div class="divider"></div>
                <p class="text-spacing-05"> Halo nama saya Ananda Arta, teman - teman saya biasa memanggil saya Arta. Saya meiliki beberapa penghargaan di beberapa bidang yang saya jalankan.</p>
                <div class="group-3-columns" data-lightgallery="group">
                  <?php
                  include_once "koneksi.php";
                  $sql = "SELECT * FROM galleryach";
                  $runSQL = mysqli_query($conn, $sql);
                    while (($row = mysqli_fetch_assoc($runSQL))) {
                  ?>
                  <div class="column-item"><a class="thumb-light" href="images/<?php echo $row["namafoto"]; ?>" data-lightgallery="item"><img src="images/<?php echo $row["namafoto"]; ?>" alt="" width="120" height="171"/>
                      <div class="thumb-light__overlay"></div></a></div>
                      <?php         
                    }
                      ?>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- My Best Photos-->
      <section class="section section-sm bg-gray-lighter text-center"> 
        <div class="shell">
          <div class="range range-50 range-sm-center">
            <div class="cell-md-10 cell-lg-9">
              <h1>My Best Photos</h1>
              <p>Inilah beberapa cuplikan foto terbaik menurut saya.</p>
            </div>
          </div>
        </div>
        <!-- Owl Carousel-->
        <?php  
               $sql = "SELECT * FROM gallerybest";
               $runSQL = mysqli_query($conn, $sql); 
               $i = 0;
          while (($row = mysqli_fetch_assoc($runSQL))) { 
               $fotogallery[$i] = $row["namafoto"];
               $judulfoto[$i] = $row["judulfoto"];
              $isian[$i] = $row["isian"];
              $i = $i + 1;
        }
         ?>
        <div class="owl-carousel-wrap owl-carousel_style-2">
          <div class="owl-carousel" data-items="1" data-lg-items="3" data-autoplay="true" data-xl-items="3" data-dots="false" data-nav="false" data-stage-padding="0" data-xs-stage-padding="90" data-sm-stage-padding="140" data-md-stage-padding="260" data-lg-stage-padding="1" data-loop="true" data-margin="0" data-mouse-drag="false" data-nav-custom="#owl-carousel-nav" data-center-mode="true" data-speed="500" data-lightgallery="group">
          <a class="thumb-ruby thumb-mixed_large" href="images/<?php echo $fotogallery[0]; ?>" data-lightgallery="item"><img class="thumb-ruby__image" src="images/<?php echo $fotogallery[0]; ?>" alt="" width="649" height="427"/>
              <div class="thumb-ruby__caption"> 
                <p class="thumb-ruby__title heading-3"><?php echo $judulfoto[0]; ?></p>
                <p class="thumb-ruby__text"><?php echo $isian[0]; ?></p>
              </div></a><a class="thumb-ruby thumb-mixed_large" href="images/<?php echo $fotogallery[1]; ?>" data-lightgallery="item"><img class="thumb-ruby__image" src="images/<?php echo $fotogallery[1]; ?>" alt="" width="649" height="427"/>
              <div class="thumb-ruby__caption"> 
                <p class="thumb-ruby__title heading-3"><?php echo $judulfoto[1]; ?></p>
                <p class="thumb-ruby__text"><?php echo $isian[1]; ?></p>
              </div></a><a class="thumb-ruby thumb-mixed_large" href="images/<?php echo $fotogallery[2]; ?>" data-lightgallery="item"><img class="thumb-ruby__image" src="images/<?php echo $fotogallery[2]; ?>" alt="" width="649" height="427"/>
              <div class="thumb-ruby__caption"> 
                <p class="thumb-ruby__title heading-3"><?php echo $judulfoto[2]; ?></p>
                <p class="thumb-ruby__text"><?php echo $isian[1]; ?></p>
              </div></a>
          </div>
          <div class="owl-outer-navigation" id="owl-carousel-nav">
            <button class="owl-arrow owl-arrow-prev">
              <svg x="0px" y="0px" viewbox="0 0 28.5 16" width="26" height="14">
                <line x1="27.5" y1="8" x2="1" y2="8" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10"></line>
                <polyline fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="8.8,15 1,8 8.8,1"></polyline>
              </svg>
            </button>
            <button class="owl-arrow owl-arrow-next">
              <svg x="0px" y="0px" viewbox="0 0 28.5 16" width="26" height="14">
                <line fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" x1="1" y1="8" x2="27.5" y2="8"></line>
                <polyline fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" points="19.7,15 27.5,8 19.7,1"></polyline>
              </svg>
            </button>
          </div>
        </div>
      </section>

      <!-- Pengalaman Saya-->
      <section class="section section-md bg-white text-center">
        <div class="shell">
          <h1>Experience</h1>
          <div class="range range-50 range-sm-center">
            <div class="cell-sm-9 cell-md-6">
                    <!-- Quote boxed-->
                    <article class="quote-boxed"><span></span><span></span><span></span><span></span>
                      <p class="quote-boxed__title">Best Moment of the year</p>
                      <div class="quote-boxed__text">
                        <svg class="quote-boxed__shape" version="1.1" x="0px" y="0px" viewbox="0 0 32.2 28" width="32.2" height="28">
                          <path d="M6.2,0C2.8,0,0,2.8,0,6.3s2.8,6.3,6.2,6.3c6.2,0,2.1,12.3-6.2,12.3v3C14.7,27.9,20.4,0,6.2,0L6.2,0z M23.9,0       c-3.4,0-6.2,2.8-6.2,6.3s2.8,6.3,6.2,6.3c6.2,0,2.1,12.3-6.2,12.3v3C32.4,27.9,38.2,0,23.9,0L23.9,0z M23.9,0"></path>
                        </svg>
                        <p>Momen terbaik yang saya punya ketika melihat keluarga saya bangga kepada saya.</p>
                      </div>
                      <ul class="quote-boxed__meta">
                        <li>
                          <div class="unit unit-horizontal unit-middle">
                            <div class="unit__left"><img class="quote-boxed__avatar" src="images/logokcl.jpg" alt="" width="46" height="46"/>
                            </div>
                            <div class="unit__body">
                              <cite class="quote-boxed__cite">Ananda Arta</cite>
                            </div>
                          </div>
                        </li>
                        <li>
                          <time class="quote-boxed__time" datetime="2019">Jul 20, 2019</time>
                        </li>
                      </ul>
                    </article>
            </div>
            <div class="cell-sm-9 cell-md-6">
                    <!-- Quote boxed-->
                    <article class="quote-boxed"><span></span><span></span><span></span><span></span>
                      <p class="quote-boxed__title">Best Place of the year</p>
                      <div class="quote-boxed__text">
                        <svg class="quote-boxed__shape" version="1.1" x="0px" y="0px" viewbox="0 0 32.2 28" width="32.2" height="28">
                          <path d="M6.2,0C2.8,0,0,2.8,0,6.3s2.8,6.3,6.2,6.3c6.2,0,2.1,12.3-6.2,12.3v3C14.7,27.9,20.4,0,6.2,0L6.2,0z M23.9,0       c-3.4,0-6.2,2.8-6.2,6.3s2.8,6.3,6.2,6.3c6.2,0,2.1,12.3-6.2,12.3v3C32.4,27.9,38.2,0,23.9,0L23.9,0z M23.9,0"></path>
                        </svg>
                        <p>Bali merupakan tempat terindah, ternyaman, terbaik, menurut saya. Karena diBali saya dapat belajar banyak hal mengenai kehidupan.</p>
                      </div>
                      <ul class="quote-boxed__meta">
                        <li>
                          <div class="unit unit-horizontal unit-middle">
                            <div class="unit__left"><img class="quote-boxed__avatar" src="images/logokcl.jpg" alt="" width="46" height="46"/>
                            </div>
                            <div class="unit__body">
                              <cite class="quote-boxed__cite">Ananda Arta</cite>
                            </div>
                          </div>
                        </li>
                        <li>
                          <time class="quote-boxed__time" datetime="2019">Jul 20, 2019</time>
                        </li>
                      </ul>
                    </article>
            </div>
          </div>
        </div>
      </section>

      <?php
        include_once "footer.php";
      ?>
    </div>
    <!-- Global Mailform Output-->
    <div class="snackbars" id="form-output-global"></div>
    <!-- Javascript-->
    <script src="js/core.min.js"></script>
    <script src="js/script.js"></script>
  </body>
</html>