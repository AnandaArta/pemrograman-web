<?php
$namaServer = "localhost";
$username = "root";
$password = "";
$namaDB = "uts_web";

//membuat koneksi
$conn = mysqli_connect($namaServer, $username, $password, $namaDB);
// check koneksi
if (!$conn){
    die("Koneksi Gagal");
}
?>