<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" />
    <!--Import materialize.css-->
    <link type="text/css" rel="stylesheet" href="assets/css/materialize.min.css" media="screen,projection" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300&display=swap" rel="stylesheet">
    <script src='https://kit.fontawesome.com/a076d05399.js'></script>
    <title>Biodata</title>
</head>
<body>
    <?php
          include_once "header.php";
    ?>
</head>
<body>
        <?php
            include_once "koneksi.php";
        ?>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1>Contact Us</h1>
                </div>
                <a href="pilihandashboard.php" class="btn btn-primary">Kembali</a>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <table id="listtable" class="table table-striped">
                        <thead>
                            <tr>
                                <th>Nama</th>
                                <th>Email</th>
                                <th>Message</th>
                                
                            </tr>
                        </thead>
                        <tbody>
<?php
//buat sql
    $query = "SELECT * FROM contact";
    $result = mysqli_query($conn, $query);
    if (mysqli_num_rows($result) < 0) {
    echo "<tr><td colspan='4'>Data profil tidak terdapat pada database</td></tr>";
} else {
  while ($row = mysqli_fetch_array($result)) {
?>
<tr>
  <td><?php echo $row["name"] ?></td>
  <td><?php echo $row["email"] ?></td>
  <td><?php echo $row["message"] ?></td>
  </tr>
<?php
        }
      } 
?>
          </tbody>
        </table>
        </div>
      </div>
    </div>
     <!-- JS, Popper.js, and jQuery -->
     <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.22/js/dataTables.bootstrap4.min.js"></script>
    <script src="//cdn.ckeditor.com/4.11.1/standard/ckeditor.js"></script>
    <script>
    $(document).ready(function() {
        $('#listtable').DataTable();
    } );
    </script>
        <?php
        include_once "footer.php";
        ?>
    </div>
</body>
</html>