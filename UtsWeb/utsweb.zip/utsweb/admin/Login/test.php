<?PHP
    include_once "koneksi.php";
    $sql = "SELECT * FROM profile WHERE id='1'";
    $runSQL = mysqli_query($conn, $sql);

    if (isset($_POST["id"])) {
        $id = $_POST["id"];
        $biodata = $_POST["biodata"];
        $organisasi = $_POST["organisasi"];
        $pendidikan = $_POST["pendidikan"];
        $keahlian = $_POST["keahlian"];
        $hobi = $_POST["hobi"];
        $penghargaan = $_POST["penghargaan"];
        $quote = $_POST["quote"];
        $portofolio = $_POST["portofolio"];

        $sql = "UPDATE profile SET biodata='".$biodata."', organisasi='".$organisasi."', pendidikan='".$pendidikan."', keahlian='".$keahlian."', hobi='".$hobi."', penghargaan='".$penghargaan."', quote='".$quote."', portofolio='".$portofolio."',";
        $runSQL = mysqli_query($conn, $sql);
        
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" />
    <!--Import materialize.css-->
    <link type="text/css" rel="stylesheet" href="assets/css/materialize.min.css" media="screen,projection" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300&display=swap" rel="stylesheet">
    <script src='https://kit.fontawesome.com/a076d05399.js'></script>
    <title>Biodata</title>
</head>
<body>
    <div class="row container-fluid">
        <div class="col">
        <?php
        if ($runSQL) {
            $jmlRowData = mysqli_num_rows($runSQL);
            if ($jmlRowData < 0) {
                echo "<tr><td colspan='5'>Data Tidak Terdapat Dalam Database</td></tr>";
                }
              else {
            while($row = mysqli_fetch_assoc($runSQL)) {
     ?>       
        <form method="POST" id="updatematkul">
            <div class="form-group">
                <label>biodata</label><br>
                <input id="id" class="form-control" type="hidden" name="id" value="<?php echo $row['id'] ?>">
                <input id="biodata" class="form-control" type="text" name="biodata" value="<?php echo $row['biodata'] ?>" required><br>
            </div>

            <div class="form-group">
                <label>Organisasi</label><br>
                <input id="organisasi" class="form-control" type="text" name="organisasi" value="<?php echo $row['organisasi'] ?>" required><br>
            </div>

            <div class="form-group">
                <label>Pendidikan</label><br>
                <input id="pendidikan" class="form-control" type="text" name="pendidikan" value="<?php echo $row['pendidikan'] ?>" required><br>
            </div>
            <div class="form-group">
                <label>Keahlian</label><br>
                <input id="keahlian" class="form-control" type="text" name="keahlian" value="<?php echo $row['keahlian'] ?>" required><br>
            </div>
            <div class="form-group">
                <label>Hobi</label><br>
                <input id="hobi" class="form-control" type="text" name="hobi" value="<?php echo $row['hobi'] ?>" required><br>
            </div>
            <div class="form-group">
                <label>Penghargaan</label><br>
                <input id="penghargaan" class="form-control" type="text" name="penghargaan" value="<?php echo $row['penghargaan'] ?>" required><br>
            </div>
            <div class="form-group">
                <label>Quote</label><br>
                <input id="quote" class="form-control" type="text" name="quote" value="<?php echo $row['quote'] ?>" required><br>
            </div>
            <div class="form-group">
                <label>Portofolio</label><br>
                <input id="portofolio" class="form-control" type="text" name="portofolio" value="<?php echo $row['portofolio'] ?>" required><br>
            </div>
            
            <input class="btn btn-primary" type="submit" value="Simpan" id="tombol">
            <br>
        </form>
        <?php
                }
            }
        }
        ?>
        </div>
    </div>
</body>
</html>