<?php
    include_once "koneksi.php";
    $sql = "SELECT * FROM profile WHERE id='1'";
    $runSQL = mysqli_query($conn, $sql);

    if (isset($_POST["id"])) {
        $id = $_POST['id'];
        $biodata = $_POST['biodata'];
        $organisasi = $_POST['organisasi'];
        $pendidikan = $_POST['pendidikan'];
        $keahlian = $_POST['keahlian'];
        $hobi = $_POST['hobi'];
        $penghargaan = $_POST['penghargaan'];
        $quote = $_POST['quote'];
        $portofolio = $_POST['portofolio'];

        $sql = "UPDATE profile SET biodata='$biodata', organisasi='$organisasi', pendidikan='$pendidikan', keahlian='$keahlian', hobi='$hobi', penghargaan='$penghargaan', quote='$quote', portofolio='$portofolio' WHERE id=$id";
        $runSQL = mysqli_query($conn, $sql);
        
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" />
    <!--Import materialize.css-->
    <link type="text/css" rel="stylesheet" href="assets/css/materialize.min.css" media="screen,projection" />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300&display=swap" rel="stylesheet">
    <script src='https://kit.fontawesome.com/a076d05399.js'></script>
    <title>Biodata</title>
</head>
<body>
    <?php
          include_once "header.php";
    ?>
    
<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <title>Halaman Dashboard</title>

  <!-- google fonts -->
  <link href="//fonts.googleapis.com/css?family=Nunito:400,700&display=swap" rel="stylesheet">

  <!-- Template CSS -->
  <link rel="stylesheet" href="assets/css/style-starter.css">

</head>

<body>
<?php
        include_once "koneksi.php";
        include_once "header.php";
        ?>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h1>Profile</h1>
                </div>
                <div class="row mb-3 mt-3">
      <div class="col-md-12">
        <a href="pilihandashboard.php" class="btn btn-primary">Kembali</a>
      </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <table id="listtable" class="table table-striped">
                        <thead>
                            <tr>
                                <th>Biodata</th>
                                <th>Organisasi</th>
                                <th>Pendidikan</th>
                                <th>Keahlian</th>
                                <th>Hobi</th>
                                <th>Penghargaan</th>
                                <th>Quote</th>
                                <th>Portofolio</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
<?php
//buat sql
    $query = "SELECT * FROM profile";
    $result = mysqli_query($conn, $query);
    if (mysqli_num_rows($result) < 0) {
    echo "<tr><td colspan='4'>Data profil tidak terdapat pada database</td></tr>";
} else {
  while ($row = mysqli_fetch_array($result)) {
?>
<tr>
  <td><?php echo $row["biodata"] ?></td>
  <td><?php echo $row["organisasi"] ?></td>
  <td><?php echo $row["pendidikan"] ?></td>
  <td><?php echo $row["keahlian"] ?></td>
  <td><?php echo $row["hobi"] ?></td>
  <td><?php echo $row["penghargaan"] ?></td>
  <td><?php echo $row["quote"] ?></td>
  <td><?php echo $row["portofolio"] ?></td>
  <td><a href="dashboard1.php?id=<?php echo $row["id"] ?>" class="btn btn-info"> <i class="fa fa-edit"></i></a></td>
  </tr>
<?php
        }
      } 
?>
          </tbody>
        </table>
        </div>
      </div>
    </div>
     <!-- JS, Popper.js, and jQuery -->
     <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <script src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.22/js/dataTables.bootstrap4.min.js"></script>
    <script src="//cdn.ckeditor.com/4.11.1/standard/ckeditor.js"></script>
    <script>
    $(document).ready(function() {
        $('#listtable').DataTable();
    } );
    </script>
        <?php
        include_once "footer.php";
        ?>
    </div>
</body>
</html>