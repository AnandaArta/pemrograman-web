<div class="container-fluid bg-dark text-white text-center p-3 m-2">
    <div class="row">
        <div class="col-md-12">Ananda Arta &copy 2020</div>
    </div>
</div>