<!DOCTYPE html>
<html class="wide wow-animation" lang="en">
  <head>
    <!-- Site Title-->
    <title>Home</title>
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <link rel="icon" href="images/logo.jpg" type="image/x-icon">
    <!-- Stylesheets-->
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Lato:300,400,700,400italic%7CJosefin+Sans:400,700,300italic">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
    <style>.ie-panel{display: none;background: #212121;padding: 10px 0;box-shadow: 3px 3px 5px 0 rgba(0,0,0,.3);clear: both;text-align:center;position: relative;z-index: 1;} html.ie-10 .ie-panel, html.lt-ie-10 .ie-panel {display: block;}</style>
  </head>
  <body>
    <!-- Page Loader-->
    <div id="page-loader">
      <div class="page-loader-body">
        <div class="cssload-spinner">
          <div class="cssload-cube cssload-cube0"></div>
          <div class="cssload-cube cssload-cube1"></div>
          <div class="cssload-cube cssload-cube2"></div>
          <div class="cssload-cube cssload-cube3"></div>
          <div class="cssload-cube cssload-cube4"></div>
          <div class="cssload-cube cssload-cube5"></div>
          <div class="cssload-cube cssload-cube6"> </div>
          <div class="cssload-cube cssload-cube7"></div>
          <div class="cssload-cube cssload-cube8"></div>
          <div class="cssload-cube cssload-cube9"></div>
          <div class="cssload-cube cssload-cube10"></div>
          <div class="cssload-cube cssload-cube11"></div>
          <div class="cssload-cube cssload-cube12"></div>
          <div class="cssload-cube cssload-cube13"></div>
          <div class="cssload-cube cssload-cube14"></div>
          <div class="cssload-cube cssload-cube15"></div>
        </div>
      </div>
    </div>
    <!-- Page-->
    <div class="page">
      <?php
          include_once "header.php";
      ?>

      <!-- My Best Photos -->
      <?php
        include_once "koneksi.php";
        $sql = "SELECT * FROM home";
        $runSQL = mysqli_query($conn, $sql);
      ?>
      <section class="section text-center">
        <!-- Slick Carousel-->
        <div class="slick-wrap">
          <div class="slick-slider slick-style-1" data-arrows="true" data-autoplay="true" data-loop="true" data-dots="true" data-swipe="true" data-xs-swipe="true" data-sm-swipe="false" data-items="1" data-sm-items="3" data-md-items="3" data-lg-items="3" data-center-mode="true" data-lightgallery="group-slick">
            <?php  while (($row = mysqli_fetch_assoc($runSQL))) {  ?>
            <div class="item">
              <div class="slick-slide-inner">
                <div class="slick-slide-caption"><a class="thumb-ann thumb-mixed_large" href="images/<?php echo $row["carousel"]; ?>" data-lightgallery="item"><img class="thumb-ann__image" src="images/<?php echo $row["carousel"]; ?>" alt="" width="961" height="664"/>
                    <div class="thumb-ann__caption"> 
                      <p class="thumb-ann__title heading-3"><?php echo $row["namacarousel"]; ?></p>
                      <p class="thumb-ann__text"><?php echo $row["desccarousel"]; ?></p>
                    </div></a>
                </div>
              </div>
            </div>
            <?php
              }
            ?>
          </div>
        </div>
      </section>
 
      <!-- About Me-->
      <section class="section section-md bg-white">
        <div class="shell">
          <div class="range range-50 range-sm-center range-md-left range-md-middle range-md-reverse">
            <div class="cell-sm-6 wow fadeInRightSmall">
              <div class="thumb-line"><img src="images/23.jpg" alt="" width="531" height="640"/>
              </div>
            </div>
            <div class="cell-sm-6">
              <div class="box-width-3">
                <p class="heading-1 wow fadeInLeftSmall">About Me</p>
                <article class="quote-big wow fadeInLeftSmall" data-wow-delay=".1s">
                  <p class="q">Ini merupakan beberapa mengenai diri saya.</p>
                </article>
                <div class="divider wow fadeInLeftSmall" data-wow-delay=".2s"></div>
                <p class="wow fadeInLeftSmall" data-wow-delay=".3s">Halo nama saya Ananda Arta, teman - teman saya biasa memanggil saya Arta. Saya meiliki beberapa penghargaan di beberapa bidang yang saya jalankan.</p><a class="button button-primary-outline button-ujarak button-size-1 wow fadeInLeftSmall" href="about-me.php" data-wow-delay=".4s">Read More</a>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- Awards-->
            <section class="section parallax-container bg-image-dark" data-parallax-img="images/16.jpg">
              <div class="parallax-content">
                <div class="section-md text-center">
                  <div class="shell">
                    <div class="range range-50 range-lg-bottom">
                      <?php  
                        $sql = "SELECT * FROM home";
                        $runSQL = mysqli_query($conn, $sql);
                        while (($row = mysqli_fetch_assoc($runSQL))) {  ?>
                      <div class="cell-xs-6 cell-md-3 wow fadeIn">
                        <!-- Box award-->
                        <article class="box-award"><img class="box-award__image" src="images/<?php echo $row["fotokcl"]; ?>" alt="" width="134" height="98"/>
                          <h3 class="box-award__title">Best Moment of <?php echo $row["tahunfotokcl"]; ?></h3>
                          <div class="box-award__divider"></div>
                          <time class="box-award__time"><?php echo $row["tahunfotokcl"]; ?></time>
                        </article>
                      </div>
                      <?php } ?>
                      </div>
                  </div>
                </div>
              </div>
            </section>

            <?php  
                        $sql = "SELECT * FROM gallerybest";
                        $runSQL = mysqli_query($conn, $sql); 
                        $i = 0;
                        while (($row = mysqli_fetch_assoc($runSQL))) { 
                          $fotogallery[$i] = $row["namafoto"];
                          $judulfoto[$i] = $row["judulfoto"];
                          $isian[$i] = $row["isian"];
                          $i = $i + 1;
                        }
            ?>

      <!-- Gallery-->
      <section class="section section-md bg-white text-center">
        <div class="shell-fluid">
          <p class="heading-1">Gallery</p>
          <div class="isotope thumb-ruby-wrap wow fadeIn" data-isotope-layout="masonry" data-isotope-group="gallery" data-lightgallery="group">
            <div class="row">
              <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3 isotope-item"><a class="thumb-ruby thumb-mixed_height-2 thumb-mixed_md" href="images/<?php echo $fotogallery[0]; ?>" data-lightgallery="item"><img class="thumb-ruby__image" src="images/<?php echo $fotogallery[0]; ?>" alt="" width="440" height="327"/>
                        <div class="thumb-ruby__caption"> 
                          <p class="thumb-ruby__title heading-3"><?php echo $judulfoto[0]; ?></p>
                          <p class="thumb-ruby__text"><?php echo $isian[0]; ?></p>
                        </div></a>
              </div>
              <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3 isotope-item"><a class="thumb-ruby thumb-mixed_height-3 thumb-mixed_md" href="images/<?php echo $fotogallery[1]; ?>" data-lightgallery="item"><img class="thumb-ruby__image" src="images/<?php echo $fotogallery[1]; ?>" alt="" width="444" height="683"/>
                        <div class="thumb-ruby__caption"> 
                          <p class="thumb-ruby__title heading-3"><?php echo $judulfoto[1]; ?></p>
                          <p class="thumb-ruby__text"><?php echo $isian[1]; ?></p>
                        </div></a>
              </div>
              <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3 isotope-item"><a class="thumb-ruby thumb-mixed_height-2 thumb-mixed_md" href="images<?php echo $fotogallery[2]; ?>" data-lightgallery="item"><img class="thumb-ruby__image" src="images/<?php echo $fotogallery[2]; ?>" alt="" width="440" height="327"/>
                        <div class="thumb-ruby__caption"> 
                          <p class="thumb-ruby__title heading-3"><?php echo $judulfoto[2]; ?></p>
                          <p class="thumb-ruby__text"><?php echo $isian[2]; ?></p>
                        </div></a>
              </div>
              <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3 isotope-item"><a class="thumb-ruby thumb-mixed_height-3 thumb-mixed_md" href="images/<?php echo $fotogallery[3]; ?>" data-lightgallery="item"><img class="thumb-ruby__image" src="images/<?php echo $fotogallery[3]; ?>" alt="" width="444" height="683"/>
                        <div class="thumb-ruby__caption"> 
                          <p class="thumb-ruby__title heading-3"><?php echo $judulfoto[3]; ?></p>
                          <p class="thumb-ruby__text"><?php echo $isian[3]; ?></p>
                        </div></a>
              </div>
              <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3 isotope-item"><a class="thumb-ruby thumb-mixed_height-2 thumb-mixed_md" href="images/<?php echo $fotogallery[4]; ?>" data-lightgallery="item"><img class="thumb-ruby__image" src="images/<?php echo $fotogallery[4]; ?>" alt="" width="440" height="327"/>
                        <div class="thumb-ruby__caption"> 
                          <p class="thumb-ruby__title heading-3"><?php echo $judulfoto[4]; ?></p>
                          <p class="thumb-ruby__text"><?php echo $isian[4]; ?></p>
                        </div></a>
              </div>
              <div class="col-xs-12 col-sm-6 col-md-4 col-lg-3 isotope-item"><a class="thumb-ruby thumb-mixed_height-2 thumb-mixed_md" href="images/<?php echo $fotogallery[5]; ?>" data-lightgallery="item"><img class="thumb-ruby__image" src="images/<?php echo $fotogallery[5]; ?>" alt="" width="440" height="327"/>
                        <div class="thumb-ruby__caption"> 
                          <p class="thumb-ruby__title heading-3"><?php echo $judulfoto[5]; ?></p>
                          <p class="thumb-ruby__text"><?php echo $isian[5]; ?></p>
                        </div></a>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- Blog-->
      <section class="section section-md bg-gray-lighter text-center">
        <div class="shell">
          <p class="heading-1">Moment</p>
          <div class="range range-30">
            <div class="cell-sm-6 cell-md-4 wow fadeInLeftSmall">
              <!-- Post boxed-->
              <article class="post-boxed">
                <ul class="post-boxed__meta">
                  <li>
                    <time datetime="2019">Jul 20, 2019</time>
                  </li>
                </ul>
                <div class="post-boxed__main">
                  <h3 class="post-boxed__title"><a href="#">Liburan di Bali</a></h3>
                  <p>Ini merupakan momen yang tidak akan pernah saya lupakan.</p>
                </div>
                <div class="post-boxed__aside">
                  <div class="unit unit-horizontal unit-middle unit-spacing-xs">
                    <div class="unit__left"><img class="post-boxed__avatar" src="images/logokcl.jpg" alt="" width="46" height="46"/>
                    </div>
                    <div class="unit__body">
                      <h6 class="text-uppercase">by Ananda Arta</h6>
                    </div>
                  </div>
                </div>
              </article>
            </div>
            <div class="cell-sm-6 cell-md-4 wow fadeInLeftSmall" data-wow-delay=".15s">
              <!-- Post boxed-->
              <article class="post-boxed">
                <ul class="post-boxed__meta">
                  <li>
                    <time datetime="2019">Jul 15, 2019</time>
                  </li>
                </ul>
                <div class="post-boxed__main">
                  <h3 class="post-boxed__title"><a href="#">Touring ke Bandung</a></h3>
                  <p>Ini merupakan momen yang tidak akan pernah saya lupakan.</p>
                </div>
                <div class="post-boxed__aside">
                  <div class="unit unit-horizontal unit-middle unit-spacing-xs">
                    <div class="unit__left"><img class="post-boxed__avatar" src="images/logokcl.jpg" alt="" width="46" height="46"/>
                    </div>
                    <div class="unit__body">
                      <h6 class="text-uppercase">by Ananda Arta</h6>
                    </div>
                  </div>
                </div>
              </article>
            </div>
            <div class="cell-sm-6 cell-md-4 wow fadeInLeftSmall" data-wow-delay=".3s">
              <!-- Post boxed-->
              <article class="post-boxed">
                <ul class="post-boxed__meta">
                  <li>
                    <time datetime="2019">Jul 5, 2019</time>
                  </li>
                </ul>
                <div class="post-boxed__main">
                  <h3 class="post-boxed__title"><a href="#">Penghargaan</a></h3>
                  <p>Saya mendapatkan beberapa penghargaan tak ternilai harganya.</p>
                </div>
                <div class="post-boxed__aside">
                  <div class="unit unit-horizontal unit-middle unit-spacing-xs">
                    <div class="unit__left"><img class="post-boxed__avatar" src="images/logokcl.jpg" alt="" width="46" height="46"/>
                    </div>
                    <div class="unit__body">
                      <h6 class="text-uppercase">by Ananda Arta</h6>
                    </div>
                  </div>
                </div>
              </article>
            </div>
          </div>
        </div>
      </section>
  <?php
    include_once "footer.php";
  ?>
    </div>
    <!-- Global Mailform Output-->
    <div class="snackbars" id="form-output-global"></div>
    <!-- Javascript-->
    <script src="js/core.min.js"></script>
    <script src="js/script.js"></script>
    <!-- coded by Himic-->
  </body>
</html>