<!DOCTYPE html>
<html class="wide wow-animation" lang="en">
  <head>
    <!-- Site Title-->
    <title>Profile</title>
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width, height=device-height, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta charset="utf-8">
    <link rel="icon" href="images/logo.jpg" type="image/x-icon">
    <!-- Stylesheets-->
    <link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Lato:300,400,700,400italic%7CJosefin+Sans:400,700,300italic">
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
    <style>.ie-panel{display: none;background: #212121;padding: 10px 0;box-shadow: 3px 3px 5px 0 rgba(0,0,0,.3);clear: both;text-align:center;position: relative;z-index: 1;} html.ie-10 .ie-panel, html.lt-ie-10 .ie-panel {display: block;}</style>
  </head>
  <body>
    <!-- Page Loader-->
    <div id="page-loader">
      <div class="page-loader-body">
        <div class="cssload-spinner">
          <div class="cssload-cube cssload-cube0"></div>
          <div class="cssload-cube cssload-cube1"></div>
          <div class="cssload-cube cssload-cube2"></div>
          <div class="cssload-cube cssload-cube3"></div>
          <div class="cssload-cube cssload-cube4"></div>
          <div class="cssload-cube cssload-cube5"></div>
          <div class="cssload-cube cssload-cube6"> </div>
          <div class="cssload-cube cssload-cube7"></div>
          <div class="cssload-cube cssload-cube8"></div>
          <div class="cssload-cube cssload-cube9"></div>
          <div class="cssload-cube cssload-cube10"></div>
          <div class="cssload-cube cssload-cube11"></div>
          <div class="cssload-cube cssload-cube12"></div>
          <div class="cssload-cube cssload-cube13"></div>
          <div class="cssload-cube cssload-cube14"></div>
          <div class="cssload-cube cssload-cube15"></div>
        </div>
      </div>
    </div>
    <!-- Page-->
    <div class="page">
      <?php
          include_once "header.php";
      ?>

      <!-- Breadcrumbs-->
      <section class="breadcrumbs-custom bg-image" style="background-image: url(images/16.jpg);">
        <div class="shell">
          <h1 class="breadcrumbs-custom__title">Profile</h1>
          <ul class="breadcrumbs-custom__path">
            <li><a href="index.php">Home</a></li>
            <li class="active">Profile</li>
          </ul>
        </div>
      </section>

      <!-- Base typography-->
      <?php
        include_once "koneksi.php";
        $sql = "SELECT * FROM profile";
        $runSQL = mysqli_query($conn, $sql);
      ?>
      <section class="section section-md bg-white">
        <div class="shell">
          <div class="range range-50">
            <div class="cell-md-10 cell-lg-8">
              <ul class="list-xl">
                  <?php
                      while ($row = mysqli_fetch_assoc($runSQL)) {
                  ?>
                <li>
                  <h1>Biodata</h1>
                  <p><?php echo $row["biodata"]; ?></p>
                </li>
                <li>
                  <h2>Organisasi</h2>
                  <p><?php echo $row["organisasi"]; ?></p>
                </li>
                <li>
                  <h2>Pendidikan</h2>
                  <p><?php echo $row["pendidikan"]; ?>
                  </p>
                </li>
                <li>
                  <h2>Keahlian</h2>
                  <p><?php echo $row["keahlian"]; ?>
                  </p>
                </li>
                <li>
                  <h2>Hobi</h2>
                  <p><?php echo $row["hobi"]; ?></p>
                </li>
                <li>
                  <h2>Penghargaan</h2>
                  <p><?php echo $row["penghargaan"]; ?></p>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <!-- Quotes-->
      <section class="section section-md bg-white">
        <div class="shell">
          <div class="range range-50">
            <div class="cell-md-10 cell-lg-8">
              <h2>Quotes</h2>
              <article class="quote-primary">
                <div class="quote-primary__body">
                  <svg class="quote-primary__mark" version="1.1" baseprofile="tiny" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="21px" height="15px" viewbox="0 0 21 15" overflow="scroll" xml:space="preserve" preserveAspectRatio="none">
                    <path d="M9.597,10.412c0,1.306-0.473,2.399-1.418,3.277c-0.944,0.876-2.06,1.316-3.349,1.316                                   c-1.287,0-2.414-0.44-3.382-1.316C0.482,12.811,0,11.758,0,10.535c0-1.226,0.58-2.716,1.739-4.473L5.603,0H9.34L6.956,6.37                                   C8.716,7.145,9.597,8.493,9.597,10.412z M20.987,10.412c0,1.306-0.473,2.399-1.418,3.277c-0.944,0.876-2.06,1.316-3.35,1.316                                   c-1.288,0-2.415-0.44-3.381-1.316c-0.966-0.879-1.45-1.931-1.45-3.154c0-1.226,0.582-2.716,1.74-4.473L16.994,0h2.734l-2.382,6.37                                   C20.106,7.145,20.987,8.493,20.987,10.412z"></path>
                  </svg>
                  <div class="quote-primary__text">
                    <p class="q"><?php echo $row["quote"]; ?></p>
                  </div>
                </div>
                <div class="quote-primary__footer">
                  <p class="heading-4 quote-primary__cite">Arta</p>
                </div>
              </article>
            </div>
          </div>
        </div>
      </section>

      <!-- Portofolio-->
      <section class="section section-md bg-white">
        <div class="shell">
          <div class="range">
            <div class="cell-md-10 cell-lg-8">
              <h2>Portofolio</h2>
              <p class="text-block"><?php echo $row["portofolio"]; ?></p>
            </div>
          </div>
        </div>
      </section>

                
      <!-- Icon List-->
      <section class="section section-md bg-white">
        <div class="shell">
          <div class="range">
            <div class="cell-xs-12">
              <h2>Skill</h2>
              <div class="range range-30 range-center">
                <div class="cell-xs-10 cell-sm-6 cell-md-4">
                  <article class="box-minimal">
                    <div class="box-minimal__icon fa fa-thumbs-up"></div>
                    <h3 class="box-minimal__title">Skill</h3>
                    <div class="box-minimal__divider"></div>
                    <div class="box-minimal__text">Saya saat ini sudah menguasai HTML, CSS, Javascript, Web Design, Jaringan Komputer.</div>
                  </article>
                </div>
                <div class="cell-xs-10 cell-sm-6 cell-md-4">
                  <article class="box-minimal">
                    <div class="box-minimal__icon fa fa-group"></div>
                    <h3 class="box-minimal__title">Reputation</h3>
                    <div class="box-minimal__divider"></div>
                    <div class="box-minimal__text">Repurtasi saya tidak perlu diragukan lagi karena sudah terbukti.</div>
                  </article>
                </div>
                <div class="cell-xs-10 cell-sm-6 cell-md-4">
                  <article class="box-minimal">
                    <div class="box-minimal__icon fa fa-thumbs-up"></div>
                    <h3 class="box-minimal__title">Moment</h3>
                    <div class="box-minimal__divider"></div>
                    <div class="box-minimal__text">Momen terbaik yang pernah saya miliki.</div>
                  </article>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <!-- Image Centered-->
      <section class="section section-md bg-white">
        <div class="shell">
          <div class="range">
            <div class="cell-md-10 cell-lg-8">
              <h2>Best Moment</h2>
              <figure class="figure-light"><img class="img-centered" src="images/<?php echo $row["moment"]; ?>" alt="" width="770" height="485"/>
                <figcaption>
                  <h2>Moment of the year</h2>
                </figcaption>
              </figure>
              <p><?php echo $row["isian"]; ?></p>
            </div>
          </div>
        </div>
      </section>

      <!-- Moment-->
      <section class="section section-md bg-white">
        <div class="shell">
          <div class="range">
            <div class="cell-md-10 cell-lg-8">
              <h2>Gallery</h2>
              <p><img src="images/<?php echo $row["gallery1"]; ?>" alt="" width="770" height="485"/><?php echo $row["isian1"]; ?>
              </p>
            </div>
          </div>
        </div>
      </section>

      <!-- Moment-->
      <section class="section section-md bg-white">
        <div class="shell">
          <div class="range">
            <div class="cell-md-10 cell-lg-8">
              <h2>Gallery</h2>
              <p><img class="img-right" src="images/<?php echo $row["gallery2"]; ?>" alt="" width="770" height="485"/><?php echo $row["isian2"]; ?>
              </p>
            </div>
          </div>
        </div>
      </section>
  
            <?php
             }
            ?>

  <?php
    include_once "footer.php";
  ?>
    </div>
    <!-- Global Mailform Output-->
    <div class="snackbars" id="form-output-global"></div>
    <!-- Javascript-->
    <script src="js/core.min.js"></script>
    <script src="js/script.js"></script>
  </body>
</html>