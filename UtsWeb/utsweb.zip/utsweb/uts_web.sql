-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 03 Nov 2020 pada 02.59
-- Versi server: 10.1.38-MariaDB
-- Versi PHP: 7.3.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `uts_web`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `aboutme`
--

CREATE TABLE `aboutme` (
  `id` int(10) NOT NULL,
  `namafoto` varchar(50) NOT NULL,
  `isian` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `aboutme`
--

INSERT INTO `aboutme` (`id`, `namafoto`, `isian`) VALUES
(1, 'logokcl.jpg', ''),
(2, 'logokcl.jpg', ''),
(3, 'logokcl.jpg', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id` int(10) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id`, `nama`, `username`, `password`) VALUES
(1, 'Test', 'test', 'test'),
(2, 'te', 'te', 'te'),
(3, 'arta', 'arta', '1234'),
(4, 'aiueo', 'aiueo', '1234'),
(5, 'alp', 'alp', '123'),
(6, 'cn', 'cn', '123'),
(7, '123', '123', '123');

-- --------------------------------------------------------

--
-- Struktur dari tabel `contact`
--

CREATE TABLE `contact` (
  `id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `message`) VALUES
(1, 'Test', 't@gmail.com', 'cdbjdsckjndskjncjdksncdsj'),
(2, 'aaa', 'aa@gmail.com', 'faasddsadaad'),
(3, 'adfas', 'a@gm.cim', 'faafasfas'),
(4, 'aiueo', 'ai@gm.com', 'abfogiyvbchlbfjadgocgadp;isbvi'),
(5, 'barry', 'barry@gm.com', 'afbcvzgvcxdvkabvsav tcu bkcvghbfscvhabvfgv ab '),
(6, 'rascal', 'rr@gm.com', 'ini website bagus'),
(7, 'aaaaaa', 'artaa@gm.com', 'test masuk tidak\n');

-- --------------------------------------------------------

--
-- Struktur dari tabel `galleryach`
--

CREATE TABLE `galleryach` (
  `id` int(11) NOT NULL,
  `namafoto` varchar(50) NOT NULL,
  `isian` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `galleryach`
--

INSERT INTO `galleryach` (`id`, `namafoto`, `isian`) VALUES
(1, 'cisco.jpg', 'CISCO'),
(2, 'html.png', 'HTML'),
(3, 'css.png', 'CSS');

-- --------------------------------------------------------

--
-- Struktur dari tabel `gallerybest`
--

CREATE TABLE `gallerybest` (
  `id` int(10) NOT NULL,
  `namafoto` varchar(50) NOT NULL,
  `judulfoto` varchar(255) NOT NULL,
  `isian` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `gallerybest`
--

INSERT INTO `gallerybest` (`id`, `namafoto`, `judulfoto`, `isian`) VALUES
(1, '23.jpg', 'Pulau', 'Liburan Di Pulau'),
(2, '30.jpg', 'Pegunungan', 'Mendaki Gunung'),
(3, '26.jpg', 'Perkemahan', 'Berkemah'),
(4, '31.jpg', 'Pegunungan', 'Pemandangan Pegunungan'),
(5, '27.jpg', 'Pantai', 'Pemandangan Pantai'),
(6, '28.jpg', 'Pantai', 'Sunset di Pantai');

-- --------------------------------------------------------

--
-- Struktur dari tabel `home`
--

CREATE TABLE `home` (
  `id` int(10) NOT NULL,
  `carousel` varchar(50) NOT NULL,
  `namacarousel` varchar(10) NOT NULL,
  `desccarousel` varchar(255) NOT NULL,
  `fotoabout` varchar(50) NOT NULL,
  `fotokcl` varchar(50) NOT NULL,
  `tahunfotokcl` varchar(5) NOT NULL,
  `gallery` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `home`
--

INSERT INTO `home` (`id`, `carousel`, `namacarousel`, `desccarousel`, `fotoabout`, `fotokcl`, `tahunfotokcl`, `gallery`) VALUES
(1, '5.jpg', 'Candi', 'Candi Borobudur', '', 'kcl4.jpg', '2017', ''),
(2, '10.jpg', 'Pegunungan', 'Pemandangan Pegunungan Himalaya', '', 'kcl1.jpg', '2018', ''),
(3, '11.jpg', 'Pantai', 'Sunset di Pantai', '', 'kcl2.jpg', '2019', ''),
(4, '17.jpg', 'Bali', 'Pantai di Bali', '', 'kcl3.jpg', '2020', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `profile`
--

CREATE TABLE `profile` (
  `id` int(10) NOT NULL,
  `biodata` text NOT NULL,
  `organisasi` text NOT NULL,
  `pendidikan` text NOT NULL,
  `keahlian` text NOT NULL,
  `hobi` text NOT NULL,
  `penghargaan` text NOT NULL,
  `quote` text NOT NULL,
  `portofolio` text NOT NULL,
  `moment` text NOT NULL,
  `isian` text NOT NULL,
  `gallery1` text NOT NULL,
  `isian1` text NOT NULL,
  `gallery2` text NOT NULL,
  `isian2` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `profile`
--

INSERT INTO `profile` (`id`, `biodata`, `organisasi`, `pendidikan`, `keahlian`, `hobi`, `penghargaan`, `quote`, `portofolio`, `moment`, `isian`, `gallery1`, `isian1`, `gallery2`, `isian2`) VALUES
(1, 'Nama saya Ananda Arta, teman - teman saya biasa memanggil saya Arta. <br>Saya Kuliah di salah satu perguruan tinggi swasta yang berada di Tangerang Selatan.', 'Saya pernah mengikuti beberapa organisasi<br>OSIS SMP<br>OSIS SMA<br>Himpunan Mahasiswa<br>Club Beladiri', 'SD<br>SMP<br>SMA<br>Kuliah', 'Beladiri<br>Otomotif', 'Renang<br>Basket<br>Muaythai<br>Boxing', 'Juara 1 Renang tingkat Kota Semarang Selatan 2008.<br>Juara 1 Muaythai antar Club Kota Tangerang Selatan.', 'Hidup tak semudah membalikkan telapak tangan, tetapi dengan telapak tangan kita dapat mengubah hidup kita jauh lebih baik lagi.<br>Jadilah pribadi yang menantang masa depan, bukan pengecut yang aman di zona nyaman.', 'Saya menguasai HTML,CSS,BOOTSTRAP,JavaScript.', 'bm17.jpg', 'ini adalah momen terbaik', 'bm18.jpg', 'salah satu momen terbaik', 'bm19.jpg', 'salah satu momen terbaik');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `aboutme`
--
ALTER TABLE `aboutme`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indeks untuk tabel `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `galleryach`
--
ALTER TABLE `galleryach`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `gallerybest`
--
ALTER TABLE `gallerybest`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `home`
--
ALTER TABLE `home`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `aboutme`
--
ALTER TABLE `aboutme`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `galleryach`
--
ALTER TABLE `galleryach`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `gallerybest`
--
ALTER TABLE `gallerybest`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `home`
--
ALTER TABLE `home`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `profile`
--
ALTER TABLE `profile`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
