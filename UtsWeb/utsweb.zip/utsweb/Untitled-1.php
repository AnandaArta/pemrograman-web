<?php
                      $sql = "SELECT * FROM gallerybest";
                      $runSQL = mysqli_query($conn, $sql);
                      while ($row = mysqli_fetch_assoc($runSQL)) {
                  ?>
              <div class="thumb-ruby__caption"> 
                <p class="thumb-ruby__title heading-3">Image #1</p>
                <p class="thumb-ruby__text"><?php echo $row["isian"]; ?></p>
              </div></a><a class="thumb-ruby thumb-mixed_large" href="images/<?php echo $row["namafoto"]; ?>" data-lightgallery="item"><img class="thumb-ruby__image" src="images/<?php echo $row["namafoto"]; ?>" alt="" width="649" height="427"/>
              <?php
                      }