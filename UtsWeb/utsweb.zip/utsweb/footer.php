<!-- Bottom Banner-->
    <!-- Page Footer-->
    <footer class="footer-centered section bg-gray-darker">
    <div class="shell">
        <div class="range range-sm-center">
        <div class="cell-sm-10 cell-md-8 cell-lg-6">
            <!-- Brand--><a class="brand" href="index.php">
            <div class="brand__name"><img src="images/logo.jpg" alt="" width="237" height="35"/>
            </div><span class="brand__slogan">story about me</span></a>
        <!-- Footer Column - Menu -->
                <div class="col-lg-3 footer_col">
                <div class="rights">
                    <div class="footer_column_content">
                        <ul>
                            <li class="footer_list_item"><a href="index.php">Home</a></li>
                            <li class="footer_list_item"><a href="about-me.php">About Me</a></li>
                            <li class="footer_list_item"><a href="profile.php">Profile</a></li>
                            <li class="footer_list_item"><a href="gallery.php">Gallery</a></li>
                            <li class="footer_list_item"><a href="contact-us.php">Contact Us</a></li>
                        </ul>
                    </div>
        </div>
        </div>
        <ul class="list-icons list-inline-sm">
                    <li><a class="icon icon-sm fa fa-instagram icon-style-camera" href="https://www.instagram.com/"><span></span><span></span><span></span><span></span></a></li>
                    <li><a class="icon icon-sm fa fa-facebook icon-style-camera" href="https://www.facebook.com/"><span></span><span></span><span></span><span></span></a></li>
                    <li><a class="icon icon-sm fa fa-twitter icon-style-camera" href="https://twitter.com/"><span></span><span></span><span></span><span></span></a></li>
                    <li><a class="icon icon-sm fa fa-envelope icon-style-camera" href="https://gmail.com"><span></span><span></span><span></span><span></span></a></li>
                    <li><a class="icon icon-sm fa fa-user icon-style-camera" href="admin/Login/index.php"><span></span><span></span><span></span><span></span></a></li>
                </ul>
            <!-- Rights-->
            <p class="rights"><span>Ananda Arta Dwi Putra</span><span>&nbsp;&copy;&nbsp; </span><span class="copyright-year"></span>.
            <br>&nbsp; <br class="veil-xs"><a class="link-underline" href="#">Privacy Policy</a><span> Design&nbsp;by&nbsp;<a href="#">Ananda Arta Dwi Putra</a></span></p>
        </div>
        </div>
    </div>
</footer>