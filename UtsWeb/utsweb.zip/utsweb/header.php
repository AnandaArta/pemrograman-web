<?php
    $activeabout = "";
    $activecontact = "";
    $activegallery = "";
    $activeindex = "";
    $activeprofile = "";

    $link = $_SERVER["REQUEST_URI"];
    //echo $link;
    if ($link == "/utsweb/index.php") {
        $activeindex = "active";
    }
    elseif ($link == "/utsweb/about-me.php") {
        $activeabout = "active";
    }
    elseif ($link == "/utsweb/profile.php") {
        $activeprofile = "active";
    }
    elseif ($link == "/utsweb/contact-us.php") {
        $activecontact = "active";
    }
    elseif ($link == "/utsweb/gallery.php") {
        $activegallery = "active";
    }
    else {
        $activeindex = "active";
    }
?>
<!-- Top Banner-->
    <!-- Page header-->
    <header class="section page-header">
    <!-- RD Navbar-->
    <div class="rd-navbar-wrap">
        <nav class="rd-navbar" data-layout="rd-navbar-fixed" data-sm-layout="rd-navbar-fixed" data-sm-device-layout="rd-navbar-fixed" data-md-layout="rd-navbar-static" data-md-device-layout="rd-navbar-fixed" data-lg-device-layout="rd-navbar-static" data-lg-layout="rd-navbar-static" data-stick-up-clone="false" data-md-stick-up-offset="5px" data-lg-stick-up-offset="5px" data-md-stick-up="true" data-lg-stick-up="true">
        <div class="rd-navbar-main-outer">
            <div class="rd-navbar-main">
            <!-- RD Navbar Panel-->
            <div class="rd-navbar-panel">
            
                <button class="rd-navbar-toggle" data-rd-navbar-toggle=".rd-navbar-nav-wrap"><span></span></button>
                <!-- RD Navbar Brand-->
                <div class="rd-navbar-brand"><a class="brand" href="index.php">
                    <div class="brand__name"><img class="brand__logo-dark" src="images/logoarta.png" alt="" width="237" height="35"/><img class="brand__logo-light" src="images/logoarta.png" alt="" width="237" height="35"/>
                    </div><span class="brand__slogan">Story About Me</span></a></div> 
            </div>
            <!-- RD Navbar Nav-->
            <div class="rd-navbar-nav-wrap">
                <div class="rd-navbar-element">
                <ul class="list-icons list-inline-sm">
                    <li><a class="icon icon-sm fa fa-instagram icon-style-camera" href="https://www.instagram.com/"><span></span><span></span><span></span><span></span></a></li>
                    <li><a class="icon icon-sm fa fa-facebook icon-style-camera" href="https://www.facebook.com/"><span></span><span></span><span></span><span></span></a></li>
                    <li><a class="icon icon-sm fa fa-twitter icon-style-camera" href="https://twitter.com/"><span></span><span></span><span></span><span></span></a></li>
                    <li><a class="icon icon-sm fa fa-envelope icon-style-camera" href="https://gmail.com"><span></span><span></span><span></span><span></span></a></li>
                    <li><a class="icon icon-sm fa fa-user" href="admin/Login/index.php"><span></span><span></span><span></span><span></span></a></li>
                </ul>
                </div>
                <!-- RD Navbar Nav-->
                <ul class="rd-navbar-nav">
                
                <li class="<?php echo $activeindex; ?>"><a href="index.php">Home<span></span><span></span><span></span><span></span></a>
                </li>
                <li class="<?php echo $activeabout; ?>"><a href="about-me.php">About Me<span></span><span></span><span></span><span></span></a>
                </li>
                <li class="<?php echo $activeprofile; ?>"><a href="profile.php">Profile<span></span><span></span><span></span><span></span></a>
                </li>
                <li class="<?php echo $activegallery; ?>"><a href="gallery.php">Gallery<span></span><span></span><span></span><span></span></a>
                </li>
                <li class="<?php echo $activecontact; ?>"><a href="contact-us.php">Contact Us<span></span><span></span><span></span><span></span></a>
                </li>
                </ul>
            </div>
            </div>
        </div>
        </nav>
    </div>
</header>